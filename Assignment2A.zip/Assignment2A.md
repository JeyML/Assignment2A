

```python
import numpy as np
```


```python
eip = np.random.random((4,3))
```


```python
print eip
```

    [[0.47080985 0.32652994 0.02007408]
     [0.00193834 0.85430181 0.03621371]
     [0.22299178 0.15203356 0.38729204]
     [0.6402986  0.00181479 0.28361409]]
    


```python
def quicksort(mlblr):
    if len(mlblr) <= 1:
        return mlblr
    pivot = mlblr[len(mlblr) // 2]
    left = [eip_in for eip_in in mlblr if eip_in < pivot]
    middle = [eip_in for eip_in in mlblr if eip_in == pivot]
    right = [eip_in for eip_in in mlblr if eip_in > pivot]
    return quicksort(left) + middle + quicksort(right)

print quicksort([3,6,8,10,1,2,1])
```

    [1, 1, 2, 3, 6, 8, 10]
    


```python
mlblr_in = 3
print mlblr_in, type(mlblr_in)

```

    3 <type 'int'>
    


```python
print mlblr_in + 1   # Addition;
print mlblr_in - 1   # Subtraction;
print mlblr_in * 2   # Multiplication;
print mlblr_in ** 2  # Exponentiation;
```

    4
    2
    6
    9
    


```python
mlblr_in += 1
print mlblr_in  # Prints "4"
mlblr_in *= 2
print mlblr_in # Prints "8"
```

    4
    8
    


```python
mlblr_out = 2.5
print type(mlblr_out) # Prints "<type 'float'>"
print mlblr_out, mlblr_out + 1, mlblr_out * 2, mlblr_out ** 2 # Prints "2.5 3.5 5.0 6.25"
```

    <type 'float'>
    2.5 3.5 5.0 6.25
    


```python
mlblr_in, mlblr_out = True, False
print type(mlblr_in) # Prints "<type 'bool'>"
```

    <type 'bool'>
    


```python
print mlblr_in and mlblr_out # Logical AND;
print mlblr_in or mlblr_out  # Logical OR;
print not mlblr_in   # Logical NOT;
print mlblr_in != mlblr_out  # Logical XOR;
```

    False
    True
    False
    True
    


```python
mlblr_in = 'hello'   # String literals can use single quotes
mlblr_out = "world"   # or double quotes; it does not matter.
print mlblr_in, len(mlblr_in)
```

    hello 5
    


```python
mlblr_in = 'hello' + ' ' + 'world'  # String concatenation
print mlblr_in  # prints "hello world"


```

    hello world
    


```python
mlblr_in = '%s %s %d' % ('hello', 'world', 12)  # sprintf style string formatting
print mlblr_in  # prints "hello world 12"
```

    hello world 12
    


```python
mlblr_out = "hello"
print mlblr_out.capitalize()  # Capitalize a string; prints "Hello"
print mlblr_out.upper()       # Convert a string to uppercase; prints "HELLO"
print mlblr_out.rjust(7)      # Right-justify a string, padding with spaces; prints "  hello"
print mlblr_out.center(7)     # Center a string, padding with spaces; prints " hello "
print mlblr_out.replace('l', '(ell)')  # Replace all instances of one substring with another;
                               # prints "he(ell)(ell)o"
print '  world '.strip()  # Strip leading and trailing whitespace; prints "world"
```

    Hello
    HELLO
      hello
     hello 
    he(ell)(ell)o
    world
    


```python
mlblr_in = [3, 1, 2]   # Create a list
print mlblr_in, mlblr_in[2]
print mlblr_in[-1]     # Negative indices count from the end of the list; prints "2"
```

    [3, 1, 2] 2
    2
    


```python
mlblr_in[2] = 'foo'    # Lists can contain elements of different types
print mlblr_in
```

    [3, 1, 'foo']
    


```python
mlblr_in.append('bar') # Add a new element to the end of the list
print mlblr_in
```

    [3, 1, 'foo', 'bar']
    


```python
mlblr_out = mlblr_in.pop()     # Remove and return the last element of the list
print mlblr_out, mlblr_in
```

    bar [3, 1, 'foo']
    


```python
eip_list = range(5)    # range is a built-in function that creates a list of integers
print eip_list         # Prints "[0, 1, 2, 3, 4]"
print eip_list[2:4]    # Get a slice from index 2 to 4 (exclusive); prints "[2, 3]"
print eip_list[2:]     # Get a slice from index 2 to the end; prints "[2, 3, 4]"
print eip_list[:2]     # Get a slice from the start to index 2 (exclusive); prints "[0, 1]"
print eip_list[:]      # Get a slice of the whole list; prints ["0, 1, 2, 3, 4]"
print eip_list[:-1]    # Slice indices can be negative; prints ["0, 1, 2, 3]"
eip_list[2:4] = [8, 9] # Assign a new sublist to a slice
print eip_list        # Prints "[0, 1, 8, 9, 4]"
```

    [0, 1, 2, 3, 4]
    [2, 3]
    [2, 3, 4]
    [0, 1]
    [0, 1, 2, 3, 4]
    [0, 1, 2, 3]
    [0, 1, 8, 9, 4]
    


```python
mlblr_out = ['cat', 'dog', 'monkey']
for mlblr_out in mlblr_out:
    print mlblr_out
```

    cat
    dog
    monkey
    


```python
eip_list = [0, 1, 2, 3, 4]
eip_dict = []
for eip_list in eip_list:
    eip_dict.append(eip_list ** 2)
print eip_dict
```

    [0, 1, 4, 9, 16]
    


```python
eip_list = [0, 1, 2, 3, 4]
eip_dict = [eip_list ** 2 for eip_list in eip_list if eip_list % 2 == 0]
print eip_dict
```

    [0, 4, 16]
    


```python
eip_dict = {'cat': 'cute', 'dog': 'furry'}  # Create a new dictionary with some data
print eip_dict['cat']       # Get an entry from a dictionary; prints "cute"
print 'cat' in eip_dict     # Check if a dictionary has a given key; prints "True"
```

    cute
    True
    


```python
eip_dict['fish'] = 'wet'    # Set an entry in a dictionary
print eip_dict['fish']      # Prints "wet"
```

    wet
    


```python
print eip_dict['monkey']  # KeyError: 'monkey' not a key of d
```


    

    KeyErrorTraceback (most recent call last)

    <ipython-input-35-b403c911b1a7> in <module>()
    ----> 1 print eip_dict['monkey']  # KeyError: 'monkey' not a key of d
    

    KeyError: 'monkey'



```python
del eip_dict['fish']        # Remove an element from a dictionary
print eip_dict.get('fish', 'N/A') # "fish" is no longer a key; prints "N/A"
```

    N/A
    


```python
eip_dict = {'person': 2, 'cat': 4, 'spider': 8}
for eip_list in eip_dict:
    eip = eip_dict[eip_list]
    print 'A %s has %d legs' % (eip_dict, eip)
```

    A {'person': 2, 'spider': 8, 'cat': 4} has 2 legs
    A {'person': 2, 'spider': 8, 'cat': 4} has 8 legs
    A {'person': 2, 'spider': 8, 'cat': 4} has 4 legs
    


```python
eip_dict = {'person': 2, 'cat': 4, 'spider': 8}
for eip_list, eip in eip_dict.iteritems():
    print 'A %s has %d legs' % (eip_list, eip)
```

    A person has 2 legs
    A spider has 8 legs
    A cat has 4 legs
    


```python
eip_list = [0, 1, 2, 3, 4]
mlblr_in = {eip_list: eip_list ** 2 for eip_list in eip_list if eip_list % 2 == 0}
print mlblr_in
```

    {0: 0, 2: 4, 4: 16}
    


```python
mlblr_in = {'cat', 'dog'}
print 'cat' in mlblr_in   # Check if an element is in a set; prints "True"
print 'fish' in mlblr_in  # prints "False"
```

    True
    False
    


```python
mlblr_in.add('fish')      # Add an element to a set
print 'fish' in mlblr_in
print len(mlblr_in)       # Number of elements in a set;
```

    True
    3
    


```python
mlblr_in.add('cat')       # Adding an element that is already in the set does nothing
print len(mlblr_in)       
mlblr_in.remove('cat')    # Remove an element from a set
print len(mlblr_in)
```

    3
    2
    


```python
eip_list = {'cat', 'dog', 'fish','man','woman','spider'}
for eip, eip_list in enumerate(eip_list):
    print '#%d: %s' % (eip + 1, eip_list)
# Prints "#1: fish", "#2: dog", "#3: cat"
```

    #1: woman
    #2: fish
    #3: spider
    #4: dog
    #5: cat
    #6: man
    


```python
from math import sqrt
print {int(sqrt(eip)) for eip in range(30)}
```

    set([0, 1, 2, 3, 4, 5])
    


```python
eip_dict = {(eip, eip + 1): eip for eip in range(10)}  # Create a dictionary with tuple keys
eip_list = (5, 6)       # Create a tuple
print type(eip_list)
print eip_dict[eip_list]       
print eip_dict[(1, 2)]
```

    <type 'tuple'>
    5
    1
    


```python
eip_list[0] = 1
```


    

    TypeErrorTraceback (most recent call last)

    <ipython-input-49-a8dd2c140e4b> in <module>()
    ----> 1 eip_list[0] = 1
    

    TypeError: 'tuple' object does not support item assignment



```python
def eip_list(eip):
    if eip > 0:
        return 'positive'
    elif eip < 0:
        return 'negative'
    else:
        return 'zero'

for eip in [-1, 0, 1,5,-5,0]:
    print eip_list(eip)
```

    negative
    zero
    positive
    positive
    negative
    zero
    


```python
def mlblr_in(name, eip=False):
    if eip:
        print 'HELLO, %s' % name.upper()
    else:
        print 'Hello, %s!' % name

mlblr_in('Bob')
mlblr_in('Fred', eip=True)
```

    Hello, Bob!
    HELLO, FRED
    


```python
class eip_in:

    # Constructor
    def __init__(self, name):
        self.name = name  # Create an instance variable

    # Instance method
    def eip_out(self, eip=False):
        if eip:
            print 'HELLO, %s!' % self.name.upper()
        else:
            print 'Hello, %s' % self.name

mlblr = eip_in('Fred')  # Construct an instance of the Greeter class
mlblr.eip_out()            # Call an instance method; prints "Hello, Fred"
mlblr.eip_out(eip=True)   # Call an instance method; prints "HELLO, FRED!"

```

    Hello, Fred
    HELLO, FRED!
    


```python
import numpy as np
```


```python
eip = np.array([1, 2, 3])  # Create a rank 1 array
print type(eip), eip.shape, eip[0], eip[1], eip[2]
eip[0] = 5                 # Change an element of the array
print eip
```

    <type 'numpy.ndarray'> (3L,) 1 2 3
    [5 2 3]
    


```python
eip = np.array([[1,2,3],[4,5,6]])   # Create a rank 2 array
print eip , eip.shape
```

    [[1 2 3]
     [4 5 6]] (2L, 3L)
    


```python
print eip.shape                   
print eip[0, 0], eip[0, 1], eip[1, 0]
```

    (2L, 3L)
    1 2 4
    


```python
eip = np.zeros((2,2))  # Create an array of all zeros
print eip
```

    [[0. 0.]
     [0. 0.]]
    


```python
eip = np.ones((1,2))   # Create an array of all ones
print eip
```

    [[1. 1.]]
    


```python
eip = np.full((2,2), 7) # Create a constant array
print eip
```

    [[7 7]
     [7 7]]
    


```python
eip = np.eye(2)        # Create a 2x2 identity matrix
print eip
```

    [[1. 0.]
     [0. 1.]]
    


```python
eip = np.random.random((2,2)) # Create an array filled with random values
print eip
```

    [[0.57543033 0.22264771]
     [0.60753298 0.78138373]]
    


```python
import numpy as np

# Create the following rank 2 array with shape (3, 4)
# [[ 1  2  3  4]
#  [ 5  6  7  8]
#  [ 9 10 11 12]]
eip = np.array([[1,2,3,4], [5,6,7,8], [9,10,11,12]])

# Use slicing to pull out the subarray consisting of the first 2 rows
# and columns 1 and 2; b is the following array of shape (2, 2):
# [[2 3]
#  [6 7]]
mlblr = eip[:2, 1:3]
print mlblr
```

    [[2 3]
     [6 7]]
    


```python
print eip[0, 1]  
mlblr[0, 0] = 77    # mlblr[0, 0] is the same piece of data as eip[0, 1]
print eip[0, 1]
```

    2
    77
    


```python
# Create the following rank 2 array with shape (3, 4)
eip = np.array([[1,2,3,4], [5,6,7,8], [9,10,11,12]])
print eip
```

    [[ 1  2  3  4]
     [ 5  6  7  8]
     [ 9 10 11 12]]
    


```python
mlblr = eip[1, :]    # Rank 1 view of the second row of a  
eip_in = eip[1:2, :]  # Rank 2 view of the second row of a
eip_out = eip[[1], :]  # Rank 2 view of the second row of a
print mlblr, mlblr.shape 
print eip_in, eip_in.shape
print eip_out, eip_out.shape
```

    [5 6 7 8] (4L,)
    [[5 6 7 8]] (1L, 4L)
    [[5 6 7 8]] (1L, 4L)
    


```python
# We can make the same distinction when accessing columns of an array:
eip_in = eip[:, 1]
eip_out = eip[:, 1:2]
print eip_in, eip_in.shape
print
print eip_out, eip_out.shape
```

    [ 2  6 10] (3L,)
    
    [[ 2]
     [ 6]
     [10]] (3L, 1L)
    


```python
eip = np.array([[1,2], [3, 4], [5, 6]])

# An example of integer array indexing.
# The returned array will have shape (3,) and 
print eip[[0, 1, 2], [0, 1, 0]]

# The above example of integer array indexing is equivalent to this:
print np.array([eip[0, 0], eip[1, 1], eip[2, 0]])
```

    [1 4 5]
    [1 4 5]
    


```python
# When using integer array indexing, you can reuse the same
# element from the source array:
print eip[[0, 0], [1, 1]]

# Equivalent to the previous integer array indexing example
print np.array([eip[0, 1], eip[0, 1]])
```

    [2 2]
    [2 2]
    


```python
# Create a new array from which we will select elements
eip = np.array([[1,2,3], [4,5,6], [7,8,9], [10, 11, 12]])
print eip
```

    [[ 1  2  3]
     [ 4  5  6]
     [ 7  8  9]
     [10 11 12]]
    


```python
# Create an array of indices
mlblr = np.array([0, 2, 0, 1])

# Select one element from each row of eip using the indices in mlblr
print eip[np.arange(4), mlblr]  # Prints "[ 1  6  7 11]"
```

    [ 1  6  7 11]
    


```python
# Mutate one element from each row of eip using the indices in mlblr
eip[np.arange(4), mlblr] += 10
print eip
```

    [[11  2  3]
     [ 4  5 16]
     [17  8  9]
     [10 21 12]]
    


```python
import numpy as np

eip = np.array([[1,2], [3, 4], [5, 6]])

bool_mlblr = (eip > 2)  # Find the elements of eip that are bigger than 2;
                    # this returns a numpy array of Booleans of the same
                    # shape as eip, where each slot of bool_mlblr tells
                    # whether that element of eip is > 2.

print bool_mlblr
```

    [[False False]
     [ True  True]
     [ True  True]]
    


```python
# We use boolean array indexing to construct a rank 1 array
# consisting of the elements of a corresponding to the True values
# of bool_mlblr
print eip[bool_mlblr]

# We can do all of the above in a single concise statement:
print eip[eip > 2]
```

    [3 4 5 6]
    [3 4 5 6]
    


```python
eip = np.array([1, 2])  # Let numpy choose the datatype
eip_in = np.array([1.0, 2.0])  # Let numpy choose the datatype
eip_out = np.array([1, 2], dtype=np.int64)  # Force a particular datatype

print eip.dtype, eip_in.dtype, eip_out.dtype
```

    int32 float64 int64
    


```python
eip = np.array([[1,2],[3,4]], dtype=np.float64)
mlblr = np.array([[5,6],[7,8]], dtype=np.float64)

# Elementwise sum; both produce the array
print eip + mlblr
print np.add(eip, mlblr)

```

    [[ 6.  8.]
     [10. 12.]]
    [[ 6.  8.]
     [10. 12.]]
    


```python
# Elementwise difference; both produce the array
print eip - mlblr
print np.subtract(eip, mlblr)
```

    [[-4. -4.]
     [-4. -4.]]
    [[-4. -4.]
     [-4. -4.]]
    


```python
# Elementwise product; both produce the array
print eip * mlblr
print np.multiply(eip, mlblr)
```

    [[ 5. 12.]
     [21. 32.]]
    [[ 5. 12.]
     [21. 32.]]
    


```python
# Elementwise division; both produce the array
# [[ 0.2         0.33333333]
#  [ 0.42857143  0.5       ]]
print eip / mlblr
print np.divide(eip, mlblr)
```

    [[0.2        0.33333333]
     [0.42857143 0.5       ]]
    [[0.2        0.33333333]
     [0.42857143 0.5       ]]
    


```python
# Elementwise square root; produces the array
# [[ 1.          1.41421356]
#  [ 1.73205081  2.        ]]
print np.sqrt(eip)
```

    [[1.         1.41421356]
     [1.73205081 2.        ]]
    


```python
eip = np.array([[1,2],[3,4]])
mlblr = np.array([[5,6],[7,8]])

eip_in = np.array([9,10])
eip_out = np.array([11, 12])

# Inner product of vectors; both produce 219
print eip_in.dot(eip_out)
print np.dot(eip_in, eip_out)
```

    219
    219
    


```python
# Matrix / vector product; both produce the rank 1 array [29 67]
print eip.dot(eip_in)
print np.dot(eip, eip_in)
```

    [29 67]
    [29 67]
    


```python
# Matrix / matrix product; both produce the rank 2 array
# [[19 22]
#  [43 50]]
print eip.dot(mlblr)
print np.dot(eip, mlblr)
```

    [[19 22]
     [43 50]]
    [[19 22]
     [43 50]]
    


```python
eip = np.array([[1,2],[3,4]])

print np.sum(eip)  # Compute sum of all elements; prints "10"
print np.sum(eip, axis=0)  # Compute sum of each column; prints "[4 6]"
print np.sum(eip, axis=1)  # Compute sum of each row; prints "[3 7]"
```

    10
    [4 6]
    [3 7]
    


```python
print eip
print eip.T
```

    [[1 2]
     [3 4]]
    [[1 3]
     [2 4]]
    


```python
mlblr = np.array([[1,2,3]])
print mlblr 
print mlblr.T
```

    [[1 2 3]]
    [[1]
     [2]
     [3]]
    


```python
# We will add the vector v to each row of the matrix x,
# storing the result in the matrix y
eip = np.array([[1,2,3], [4,5,6], [7,8,9], [10, 11, 12]])
eip_in = np.array([1, 0, 1])
eip_out = np.empty_like(eip)   # Create an empty matrix with the same shape as eip

# Add the vector eip_in to each row of the matrix eip with an explicit loop
for mlblr in range(4):
    eip_out[mlblr, :] = eip[mlblr, :] + eip_in

print eip_out
```

    [[ 2  2  4]
     [ 5  5  7]
     [ 8  8 10]
     [11 11 13]]
    


```python
eip_list = np.tile(eip_in, (4, 1))  # Stack 4 copies of eip_in on top of each other
print eip_list                 # Prints "[[1 0 1]
                         #          [1 0 1]
                         #          [1 0 1]
                         #          [1 0 1]]"
```

    [[1 0 1]
     [1 0 1]
     [1 0 1]
     [1 0 1]]
    


```python
eip_dict = eip + eip_list  # Add eip and eip_list elementwise
print eip_dict
```

    [[ 2  2  4]
     [ 5  5  7]
     [ 8  8 10]
     [11 11 13]]
    


```python
import numpy as np

# We will add the vector eip_in to each row of the matrix eip,
# storing the result in the matrix eip_dict
eip = np.array([[1,2,3], [4,5,6], [7,8,9], [10, 11, 12]])
eip_in = np.array([1, 0, 1])
eip_dict = eip + eip_in  # Add eip_in to each row of eip using broadcasting
print eip_dict

```

    [[ 2  2  4]
     [ 5  5  7]
     [ 8  8 10]
     [11 11 13]]
    


```python
# Compute outer product of vectors
eip_in = np.array([1,2,3])  # eip_in has shape (3,)
mlblr = np.array([4,5])    # mlblr has shape (2,)
# To compute an outer product, we first reshape eip_in to be a column
# vector of shape (3, 1); we can then broadcast it against mlblr to yield
# an output of shape (3, 2), which is the outer product of eip_in and mlblr:

print np.reshape(eip_in, (3, 1)) * mlblr
```

    [[ 4  5]
     [ 8 10]
     [12 15]]
    


```python
# Add a vector to each row of a matrix
eip = np.array([[1,2,3], [4,5,6]])
# eip has shape (2, 3) and eip_in has shape (3,) so they broadcast to (2, 3),
# giving the following matrix:

print eip + eip_in
```

    [[2 4 6]
     [5 7 9]]
    


```python
# Add a vector to each column of a matrix
# eip has shape (2, 3) and mlblr has shape (2,).
# If we transpose eip then it has shape (3, 2) and can be broadcast
# against mlblr to yield a result of shape (3, 2); transposing this result
# yields the final result of shape (2, 3) which is the matrix eip with
# the vector mlblr added to each column. Gives the following matrix:

print (eip.T + mlblr).T
```

    [[ 5  6  7]
     [ 9 10 11]]
    


```python
# Another solution is to reshape mlblr to be a row vector of shape (2, 1);
# we can then broadcast it directly against eip to produce the same
# output.
print eip + np.reshape(mlblr, (2, 1))
```

    [[ 5  6  7]
     [ 9 10 11]]
    


```python
# Multiply a matrix by a constant:
# eip has shape (2, 3). Numpy treats scalars as arrays of shape ();
# these can be broadcast together to shape (2, 3), producing the
# following array:
print eip * 2
```

    [[ 2  4  6]
     [ 8 10 12]]
    


```python
import matplotlib.pyplot as plt
```


```python
%matplotlib inline
```


```python
# Compute the x and y coordinates for points on a sine curve
eip = np.arange(0, 3 * np.pi, 0.1)
eip_in = np.sin(eip)

# Plot the points using matplotlib
plt.plot(eip, eip_in)
```




    [<matplotlib.lines.Line2D at 0x8358b00>]




![png](output_83_1.png)



```python
eip_in_sin = np.sin(eip)
eip_in_cos = np.cos(eip)

# Plot the points using matplotlib
plt.plot(eip, eip_in_sin)
plt.plot(eip, eip_in_cos)
plt.xlabel('x axis label')
plt.ylabel('y axis label')
plt.title('Sine and Cosine')
plt.legend(['Sine', 'Cosine'])
```




    <matplotlib.legend.Legend at 0x8650ef0>




![png](output_84_1.png)



```python
# Compute the x and y coordinates for points on sine and cosine curves
eip = np.arange(0, 3 * np.pi, 0.1)
eip_in_sin = np.sin(eip)
eip_in_cos = np.cos(eip)

# Set up a subplot grid that has height 2 and width 1,
# and set the first such subplot as active.
plt.subplot(2, 1, 1)

# Make the first plot
plt.plot(eip, eip_in_sin)
plt.title('Sine')

# Set the second subplot as active, and make the second plot.
plt.subplot(2, 1, 2)
plt.plot(eip, eip_in_cos)
plt.title('Cosine')

# Show the figure.
plt.show()
```


![png](output_85_0.png)

